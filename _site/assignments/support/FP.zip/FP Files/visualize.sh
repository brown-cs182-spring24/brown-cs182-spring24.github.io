# if you're coding in python, you don't need to worry about this file!
# shell script to visualize a fold, given a sequence and an LFR sequence

python3 stencil.py $@