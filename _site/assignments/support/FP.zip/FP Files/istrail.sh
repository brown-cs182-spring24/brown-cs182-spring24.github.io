# shell script to fold your proteins!

python3 istrail.py $@