import matplotlib.pyplot as plt
import sys

# A static dictionary mapping amino acids to HP
HP_MAP = {'A' : 'H', 'R' : 'P', 'N' : 'P', 'D' : 'P', 'C' : 'P', 'E' : 'P', 'Q' : 'P', 'G' : 'H', 'H' : 'P', 'I' : 'H', 'L' : 'H', 'K' : 'P', 'M' : 'H', 'F' : 'H', 'P' : 'H', 'S' : 'P', 'T' : 'P', 'W' : 'H', 'Y' : 'P', 'V' : 'H'}

def visualize(seq : str, fold : str):
    '''
    A function to visualize a protein sequence folded according to the LFR 
    string given.

    Parameters
    ----------
    seq - the amino acid sequence to visualize
    fold - the LFR string that defines how we fold seq

    Returns
    -------
    Nothing, just shows the visualization via matplotlib
    '''

    # start fold at the origin
    x, y = [0], [0]

    # ensure the fold is length n - 1, for a sequence of length n
    assert(len(seq) == len(fold) + 1)

    # initialize forward direction
    cdirx, cdiry = 0, 1

    # loop over LFR sequence, loading in coordinates for each amino acid
    for dir in fold:
        match dir:
            case 'L':
                cdirx, cdiry = -1*cdiry, 1*cdirx
            case 'R':
                cdirx, cdiry = 1*cdiry, -1*cdirx
        x.append(x[-1] + cdirx)
        y.append(y[-1] + cdiry)

    # visualization code (no need to understand this, but feel free to tweak it)
    _, ax = plt.subplots()

    ax.plot(x, y, marker='o', markersize=20, linestyle='-', color='deepskyblue', linewidth=2)

    for i, label in enumerate([*seq]):
        ax.annotate(label, (x[i], y[i]), color='white', weight='bold', fontsize=10, ha='center', va='center')

    ax.grid(True, which='both', linestyle='--', linewidth=0.5)
    ax.set_xticks(x)
    ax.set_yticks(y)

    padding = 1
    ax.set_xlim(min(x)-padding, max(x)+padding)
    ax.set_ylim(min(y)-padding, max(y)+padding)

    ax.set_title('Folded Protein')
    ax.set_xlabel('Lattice Axis 1')
    ax.set_ylabel('Lattice Axis 2')

    ax.set_facecolor('whitesmoke')

    plt.show()

if __name__ == '__main__':
    if not(len(sys.argv) == 3):
        print('Usage: sh visualize.sh <seq> <fold> – input these as strings, or modify this to handle files!')
    visualize(sys.argv[1], sys.argv[2])