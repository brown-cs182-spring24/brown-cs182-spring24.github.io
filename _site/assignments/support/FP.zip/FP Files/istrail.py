import sys
from stencil import visualize, HP_MAP

if __name__ == '__main__':
    if not(len(sys.argv) == 2):
        print('Usage: python3 istrail.py <seq.txt>')

    # you might want to use HP_MAP somewhere in here!

    visualize('ABCD', 'FRR')
    

