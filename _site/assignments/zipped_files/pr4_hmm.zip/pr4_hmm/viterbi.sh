# This is the shell script responsible for running your implementation of the 
# Viterbi algorithm.
# Two arguments must be passed in: a txt file with the desired configuration 
# and a txt file with an observation.
# Remember to use python3!
