# This example shell script directly calls the python interpreter
# on a hypothetical python script that will do KMP.
# It also passes the one argument that this script is called with.
# The one argument will be the path (absolute or relative) to the sequence file.
# You'll need to edit this file for the language of your choosing.
# Come to office hours if you need additional clarification.
python kmp.py ${1} 
