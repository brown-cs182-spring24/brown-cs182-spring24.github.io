
python fegalignment.py ${1} ${2}
