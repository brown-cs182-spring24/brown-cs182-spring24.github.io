# Fill in the blank line with the command or commands that will run your program. Make sure it takes in arguments $1 and $2, which refers to the strings to calculate the hamming distance between. Print your results to standard out.

# For example, if your program is written in Python, you might put
# python3 hamming.py $1 $2
###############################



###############################

# You can run your script by running
# sh hamming.sh GAGCCTACTAACGGGAT CATCGTAATGACGGCCT
